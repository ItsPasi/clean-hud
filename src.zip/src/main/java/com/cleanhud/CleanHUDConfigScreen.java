package com.cleanhud;

import dev.isxander.yacl3.api.ConfigCategory;
import dev.isxander.yacl3.api.Option;
import dev.isxander.yacl3.api.OptionDescription;
import dev.isxander.yacl3.api.StateManager;
import dev.isxander.yacl3.api.YetAnotherConfigLib;
import dev.isxander.yacl3.api.controller.BooleanControllerBuilder;
import dev.isxander.yacl3.api.controller.EnumControllerBuilder;
import dev.isxander.yacl3.api.controller.TickBoxControllerBuilder;

import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.function.Consumer;
import java.util.function.Supplier;

public class CleanHUDConfigScreen {
	public static Screen create(Screen parent) {
		final CleanHUDPreset[] selectedPreset = {CleanHUDConfig.INSTANCE.preset};

		class PresetState {
			boolean applyingPreset;
			Option<CleanHUDPreset> presetOption;

			void markCustom() {
				if (applyingPreset) {
					return;
				}

				CleanHUDConfig.markCustomPreset();
				selectedPreset[0] = CleanHUDPreset.CUSTOM;

				if (presetOption != null) {
					presetOption.requestSet(CleanHUDPreset.CUSTOM);
				}
			}
		}

		PresetState presetState = new PresetState();

		Option<ArmorHudPosition> armorPositionOption = armorPositionOption(
				"Armor HUD Position",
				"Bottom places armor next to the hotbar, Left places it at the middle-left edge, and Off hides it.",
				() -> CleanHUDConfig.INSTANCE.armorHudPosition,
				value -> {
					CleanHUDConfig.INSTANCE.armorHudPosition = value;
					presetState.markCustom();
				},
				CleanHUDConfig.defaults().armorHudPosition
		);

		Option<Boolean> armorBackgroundOption = backgroundToggleOption(
				"Armor HUD Background",
				"Draws the offhand-style slot background behind armor.",
				() -> CleanHUDConfig.INSTANCE.armorHudBackground,
				value -> {
					CleanHUDConfig.INSTANCE.armorHudBackground = value;
					presetState.markCustom();
				},
				CleanHUDConfig.defaults().armorHudBackground
		);

		Option<EffectHudPosition> effectPositionOption = effectPositionOption(
				"Effect HUD Position",
				"Bottom places effects next to the hotbar, Top places them below boss bars, and Off hides them.",
				() -> CleanHUDConfig.INSTANCE.effectHudPosition,
				value -> {
					CleanHUDConfig.INSTANCE.effectHudPosition = value;
					presetState.markCustom();
				},
				CleanHUDConfig.defaults().effectHudPosition
		);

		Option<Boolean> effectBackgroundOption = backgroundToggleOption(
				"Effect HUD Background",
				"Draws the offhand-style slot background behind effects. The arrow HUD always keeps its background.",
				() -> CleanHUDConfig.INSTANCE.effectHudBackground,
				value -> {
					CleanHUDConfig.INSTANCE.effectHudBackground = value;
					presetState.markCustom();
				},
				CleanHUDConfig.defaults().effectHudBackground
		);

		Option<Boolean> arrowDisplayOption = booleanOption(
				"Arrow Display",
				"Shows the arrow counter beside the hotbar while holding a bow or crossbow.",
				() -> CleanHUDConfig.INSTANCE.showArrowHud,
				value -> {
					CleanHUDConfig.INSTANCE.showArrowHud = value;
					presetState.markCustom();
				},
				CleanHUDConfig.defaults().showArrowHud
		);

		Option<Boolean> clockOption = booleanOption(
				"Clock",
				"Shows the system time in the bottom-right corner.",
				() -> CleanHUDConfig.INSTANCE.showClock,
				value -> {
					CleanHUDConfig.INSTANCE.showClock = value;
					presetState.markCustom();
				},
				CleanHUDConfig.defaults().showClock
		);

		Option<CleanHUDPreset> presetOption = Option.<CleanHUDPreset>createBuilder()
				.name(Component.literal("Preset"))
				.description(OptionDescription.of(Component.literal("Hotbar uses the bottom layout. Dynamic moves armor left, moves effects top, and disables the effect background.")))
				.stateManager(StateManager.createSimple(CleanHUDConfig.defaults().preset, () -> selectedPreset[0], value -> {
					if (value == null) {
						return;
					}

					selectedPreset[0] = value;

					if (value == CleanHUDPreset.CUSTOM) {
						CleanHUDConfig.markCustomPreset();
						return;
					}

					presetState.applyingPreset = true;
					try {
						CleanHUDConfig.applyPreset(value);
						armorPositionOption.requestSet(CleanHUDConfig.INSTANCE.armorHudPosition);
						armorBackgroundOption.requestSet(CleanHUDConfig.INSTANCE.armorHudBackground);
						effectPositionOption.requestSet(CleanHUDConfig.INSTANCE.effectHudPosition);
						effectBackgroundOption.requestSet(CleanHUDConfig.INSTANCE.effectHudBackground);
					} finally {
						presetState.applyingPreset = false;
					}
				}))
				.controller(option -> EnumControllerBuilder.create(option).enumClass(CleanHUDPreset.class).formatValue(CleanHUDConfigScreen::presetComponent))
				.build();

		presetState.presetOption = presetOption;

		return YetAnotherConfigLib.createBuilder()
				.title(Component.literal("Clean HUD"))
				.category(ConfigCategory.createBuilder()
						.name(Component.literal("HUD"))
						.option(presetOption)
						.option(armorPositionOption)
						.option(armorBackgroundOption)
						.option(effectPositionOption)
						.option(effectBackgroundOption)
						.option(arrowDisplayOption)
						.option(clockOption)
						.build())
				.save(() -> {
					if (selectedPreset[0] == null) {
						selectedPreset[0] = CleanHUDConfig.INSTANCE.preset == null ? CleanHUDPreset.CUSTOM : CleanHUDConfig.INSTANCE.preset;
					}

					if (selectedPreset[0] == CleanHUDPreset.CUSTOM) {
						CleanHUDConfig.markCustomPreset();
					} else {
						CleanHUDConfig.applyPreset(selectedPreset[0]);
					}

					CleanHUDConfig.save();
				})
				.build()
				.generateScreen(parent);
	}

	private static Option<Boolean> booleanOption(String name, String description, Supplier<Boolean> getter, Consumer<Boolean> setter, boolean defaultValue) {
		return Option.<Boolean>createBuilder()
				.name(Component.literal(name))
				.description(OptionDescription.of(Component.literal(description)))
				.stateManager(StateManager.createSimple(defaultValue, getter, setter))
				.controller(option -> BooleanControllerBuilder.create(option).formatValue(CleanHUDConfigScreen::booleanComponent))
				.build();
	}

	private static Option<Boolean> backgroundToggleOption(String name, String description, Supplier<Boolean> getter, Consumer<Boolean> setter, boolean defaultValue) {
		return Option.<Boolean>createBuilder()
				.name(Component.literal(name))
				.description(OptionDescription.of(Component.literal(description)))
				.stateManager(StateManager.createSimple(defaultValue, getter, setter))
				.controller(TickBoxControllerBuilder::create)
				.build();
	}

	private static Option<ArmorHudPosition> armorPositionOption(String name, String description, Supplier<ArmorHudPosition> getter, Consumer<ArmorHudPosition> setter, ArmorHudPosition defaultValue) {
		return Option.<ArmorHudPosition>createBuilder()
				.name(Component.literal(name))
				.description(OptionDescription.of(Component.literal(description)))
				.stateManager(StateManager.createSimple(defaultValue, getter, setter))
				.controller(option -> EnumControllerBuilder.create(option).enumClass(ArmorHudPosition.class).formatValue(CleanHUDConfigScreen::armorPositionComponent))
				.build();
	}

	private static Option<EffectHudPosition> effectPositionOption(String name, String description, Supplier<EffectHudPosition> getter, Consumer<EffectHudPosition> setter, EffectHudPosition defaultValue) {
		return Option.<EffectHudPosition>createBuilder()
				.name(Component.literal(name))
				.description(OptionDescription.of(Component.literal(description)))
				.stateManager(StateManager.createSimple(defaultValue, getter, setter))
				.controller(option -> EnumControllerBuilder.create(option).enumClass(EffectHudPosition.class).formatValue(CleanHUDConfigScreen::effectPositionComponent))
				.build();
	}

	private static Component presetComponent(CleanHUDPreset value) {
		return switch (value) {
			case HOTBAR -> Component.literal("Hotbar").withStyle(ChatFormatting.WHITE);
			case DYNAMIC -> Component.literal("Dynamic").withStyle(ChatFormatting.WHITE);
			case CUSTOM -> Component.literal("Custom").withStyle(ChatFormatting.WHITE);
		};
	}

	private static Component booleanComponent(boolean value) {
		return Component.literal(value ? "ON" : "OFF").withStyle(value ? ChatFormatting.GREEN : ChatFormatting.RED);
	}

	private static Component armorPositionComponent(ArmorHudPosition value) {
		return switch (value) {
			case BOTTOM -> Component.literal("Bottom").withStyle(ChatFormatting.WHITE);
			case LEFT -> Component.literal("Left").withStyle(ChatFormatting.WHITE);
			case OFF -> Component.literal("Off").withStyle(ChatFormatting.RED);
		};
	}

	private static Component effectPositionComponent(EffectHudPosition value) {
		return switch (value) {
			case BOTTOM -> Component.literal("Bottom").withStyle(ChatFormatting.WHITE);
			case TOP -> Component.literal("Top").withStyle(ChatFormatting.WHITE);
			case OFF -> Component.literal("Off").withStyle(ChatFormatting.RED);
		};
	}
}
