package com.cleanhud;

import net.fabricmc.loader.api.FabricLoader;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

public class CleanHUDConfig {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final Path CONFIG_PATH = FabricLoader.getInstance().getConfigDir().resolve(CleanHUD.MOD_ID + ".json");
	private static final CleanHUDConfig DEFAULTS = new CleanHUDConfig();

	public static CleanHUDConfig INSTANCE = new CleanHUDConfig();

	public CleanHUDPreset preset = CleanHUDPreset.HOTBAR;
	public ArmorHudPosition armorHudPosition = ArmorHudPosition.BOTTOM;
	public boolean armorHudBackground = true;
	public EffectHudPosition effectHudPosition = EffectHudPosition.BOTTOM;
	public boolean effectHudBackground = true;
	public boolean showArrowHud = true;
	public boolean showClock = true;

	public static CleanHUDConfig defaults() {
		return DEFAULTS;
	}

	public static void load() {
		if (!Files.exists(CONFIG_PATH)) {
			INSTANCE = new CleanHUDConfig();
			save();
			return;
		}

		try (Reader reader = Files.newBufferedReader(CONFIG_PATH)) {
			CleanHUDConfig loaded = GSON.fromJson(reader, CleanHUDConfig.class);
			INSTANCE = loaded != null ? loaded : new CleanHUDConfig();
			sanitize();
		} catch (Exception exception) {
			CleanHUD.LOGGER.warn("Failed to load Clean HUD config, using defaults", exception);
			INSTANCE = new CleanHUDConfig();
		}
	}

	private static void sanitize() {
		if (INSTANCE.preset == null) {
			INSTANCE.preset = CleanHUDPreset.HOTBAR;
		}

		if (INSTANCE.armorHudPosition == null) {
			INSTANCE.armorHudPosition = ArmorHudPosition.BOTTOM;
		}

		if (INSTANCE.effectHudPosition == null) {
			INSTANCE.effectHudPosition = EffectHudPosition.BOTTOM;
		}
	}

	public static void applyPreset(CleanHUDPreset preset) {
		if (preset == null) {
			return;
		}

		INSTANCE.preset = preset;

		switch (preset) {
			case HOTBAR -> {
				INSTANCE.armorHudPosition = ArmorHudPosition.BOTTOM;
				INSTANCE.armorHudBackground = true;
				INSTANCE.effectHudPosition = EffectHudPosition.BOTTOM;
				INSTANCE.effectHudBackground = true;
			}
			case DYNAMIC -> {
				INSTANCE.armorHudPosition = ArmorHudPosition.LEFT;
				INSTANCE.armorHudBackground = true;
				INSTANCE.effectHudPosition = EffectHudPosition.TOP;
				INSTANCE.effectHudBackground = false;
			}
			case CUSTOM -> {
			}
		}
	}

	public static void markCustomPreset() {
		INSTANCE.preset = CleanHUDPreset.CUSTOM;
	}

	public static void save() {
		try {
			Files.createDirectories(CONFIG_PATH.getParent());
			try (Writer writer = Files.newBufferedWriter(CONFIG_PATH)) {
				GSON.toJson(INSTANCE, writer);
			}
		} catch (IOException exception) {
			CleanHUD.LOGGER.warn("Failed to save Clean HUD config", exception);
		}
	}
}
