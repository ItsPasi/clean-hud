package com.cleanhud;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.lang.reflect.Field;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class CleanHUDRenderer {
	private static final int HOTBAR_WIDTH = 182;
	private static final int HOTBAR_HEIGHT = 22;
	private static final int ITEM_SIZE = 16;
	private static final int EFFECT_ICON_SIZE = 18;
	private static final int SIDE_SLOT_ADVANCE = 29;
	private static final int GROUP_SLOT_ADVANCE = 23;
	private static final int OFFHAND_BACKGROUND_WIDTH = 29;
	private static final int OFFHAND_BACKGROUND_HEIGHT = 24;
	private static final int LEFT_OFFHAND_ITEM_OFFSET = 3;
	private static final int RIGHT_OFFHAND_ITEM_OFFSET = 10;
	private static final int EFFECT_ICON_X_OFFSET = RIGHT_OFFHAND_ITEM_OFFSET - 1;
	private static final int EFFECT_ICON_Y_OFFSET = 3;
	private static final int OFFHAND_ITEM_Y_OFFSET = 4;
	private static final int CLOCK_RIGHT_EXTRA_PADDING = 2;
	private static final int CLOCK_PADDING = 2;
	private static final int EFFECT_ROW_ADVANCE = GROUP_SLOT_ADVANCE;
	private static final int TOP_EFFECT_ROW_ADVANCE = OFFHAND_BACKGROUND_HEIGHT + 11;
	private static final int SCREEN_EDGE_PADDING = 2;

	private static final Identifier HOTBAR_OFFHAND_LEFT_SPRITE = Identifier.withDefaultNamespace("hud/hotbar_offhand_left");
	private static final Identifier HOTBAR_OFFHAND_RIGHT_SPRITE = Identifier.withDefaultNamespace("hud/hotbar_offhand_right");

	private static final int TEXT_COLOR = 0xFFFFFFFF;
	private static final int LOW_TEXT_COLOR = 0xFFFF5555;
	private static final int SHADOW_COLOR = 0xAA000000;
	private static final DateTimeFormatter CLOCK_FORMAT = DateTimeFormatter.ofPattern("HH:mm:ss");

	private static final Map<String, Integer> EFFECT_MAX_DURATIONS = new HashMap<>();

	public static void render(GuiGraphicsExtractor graphics, DeltaTracker tickCounter) {
		Minecraft minecraft = Minecraft.getInstance();
		LocalPlayer player = minecraft.player;

		if (minecraft.options.hideGui || player == null) {
			return;
		}

		int guiWidth = graphics.guiWidth();
		int guiHeight = graphics.guiHeight();
		int hotbarLeft = guiWidth / 2 - HOTBAR_WIDTH / 2;
		int hotbarRight = hotbarLeft + HOTBAR_WIDTH;
		int hotbarY = guiHeight - HOTBAR_HEIGHT - 1;

		boolean hasOffhandItem = !player.getOffhandItem().isEmpty();
		boolean offhandOnLeft = hasOffhandItem && player.getMainArm() == HumanoidArm.RIGHT;
		boolean offhandOnRight = hasOffhandItem && player.getMainArm() == HumanoidArm.LEFT;

		if (CleanHUDConfig.INSTANCE.armorHudPosition.showsHud()) {
			renderArmor(graphics, minecraft.font, player, hotbarLeft, hotbarY, offhandOnLeft, guiHeight);
		}

		if (CleanHUDConfig.INSTANCE.showClock) {
			renderClock(graphics, minecraft.font, guiWidth, guiHeight);
		}

		int arrowOffset = CleanHUDConfig.INSTANCE.showArrowHud
				? renderArrowHud(graphics, minecraft.font, player, hotbarRight, hotbarY, offhandOnRight)
				: 0;

		if (CleanHUDConfig.INSTANCE.effectHudPosition.showsHud()) {
			renderEffects(graphics, minecraft, player, hotbarRight, hotbarY, offhandOnRight, guiWidth, guiHeight, arrowOffset);
		}
	}

	private static void renderArmor(GuiGraphicsExtractor graphics, Font font, LocalPlayer player, int hotbarLeft, int hotbarY, boolean offhandOnLeft, int guiHeight) {
		List<ItemStack> armorStacks = getArmorStacks(player);

		if (CleanHUDConfig.INSTANCE.armorHudPosition == ArmorHudPosition.LEFT) {
			renderArmorLeft(graphics, font, armorStacks, guiHeight);
		} else {
			renderArmorBottom(graphics, font, armorStacks, hotbarLeft, hotbarY, offhandOnLeft);
		}
	}

	private static List<ItemStack> getArmorStacks(LocalPlayer player) {
		List<ItemStack> armorStacks = new ArrayList<>();
		addIfPresent(armorStacks, player.getItemBySlot(EquipmentSlot.HEAD));
		addIfPresent(armorStacks, player.getItemBySlot(EquipmentSlot.CHEST));
		addIfPresent(armorStacks, player.getItemBySlot(EquipmentSlot.LEGS));
		addIfPresent(armorStacks, player.getItemBySlot(EquipmentSlot.FEET));
		return armorStacks;
	}

	private static void renderArmorBottom(GuiGraphicsExtractor graphics, Font font, List<ItemStack> armorStacks, int hotbarLeft, int hotbarY, boolean offhandOnLeft) {
		int firstSlotX = hotbarLeft - OFFHAND_BACKGROUND_WIDTH - (offhandOnLeft ? SIDE_SLOT_ADVANCE : 0);
		int startSlotX = firstSlotX - (armorStacks.size() - 1) * GROUP_SLOT_ADVANCE;

		for (int i = 0; i < armorStacks.size(); i++) {
			drawArmorSlot(graphics, font, armorStacks.get(i), startSlotX + i * GROUP_SLOT_ADVANCE, hotbarY);
		}
	}

	private static void renderArmorLeft(GuiGraphicsExtractor graphics, Font font, List<ItemStack> armorStacks, int guiHeight) {
		int columnHeight = OFFHAND_BACKGROUND_HEIGHT + Math.max(0, armorStacks.size() - 1) * GROUP_SLOT_ADVANCE;
		int startSlotY = guiHeight / 2 - columnHeight / 2;

		for (int i = 0; i < armorStacks.size(); i++) {
			drawArmorSlot(graphics, font, armorStacks.get(i), SCREEN_EDGE_PADDING, startSlotY + i * GROUP_SLOT_ADVANCE);
		}
	}

	private static void drawArmorSlot(GuiGraphicsExtractor graphics, Font font, ItemStack stack, int slotX, int slotY) {
		int itemX = slotX + LEFT_OFFHAND_ITEM_OFFSET;
		int itemY = slotY + OFFHAND_ITEM_Y_OFFSET;

		if (CleanHUDConfig.INSTANCE.armorHudBackground) {
			drawOffhandBackground(graphics, slotX, slotY, true);
		}

		graphics.item(stack, itemX, itemY);
		graphics.itemDecorations(font, stack, itemX, itemY);
		drawLowDurabilityText(graphics, font, stack, itemX, itemY);
	}

	private static void drawLowDurabilityText(GuiGraphicsExtractor graphics, Font font, ItemStack stack, int itemX, int itemY) {
		if (!stack.isDamageableItem()) {
			return;
		}

		int maxDamage = stack.getMaxDamage();

		if (maxDamage <= 0) {
			return;
		}

		int durabilityLeft = Math.max(0, maxDamage - stack.getDamageValue());
		int barWidth = Math.max(0, Math.min(13, Math.round(13.0F * durabilityLeft / maxDamage)));

		if (barWidth > 2) {
			return;
		}

		String text = Integer.toString(durabilityLeft);
		int color = LOW_TEXT_COLOR;
		int x = itemX + ITEM_SIZE - font.width(text) + 1;
		int y = itemY + ITEM_SIZE - font.lineHeight + 2;

		drawTextWithShadow(graphics, font, text, x, y, color);
	}

	private static void addIfPresent(List<ItemStack> stacks, ItemStack stack) {
		if (!stack.isEmpty()) {
			stacks.add(stack);
		}
	}

	private static int renderArrowHud(GuiGraphicsExtractor graphics, Font font, LocalPlayer player, int hotbarRight, int hotbarY, boolean offhandOnRight) {
		ItemStack arrowStack = findArrowStack(player);

		if (!isHoldingBowOrCrossbow(player) || arrowStack.isEmpty()) {
			return 0;
		}

		int slotX = hotbarRight + (offhandOnRight ? SIDE_SLOT_ADVANCE : 0);
		int itemX = slotX + RIGHT_OFFHAND_ITEM_OFFSET;
		int itemY = hotbarY + OFFHAND_ITEM_Y_OFFSET;

		drawOffhandBackground(graphics, slotX, hotbarY, false);
		graphics.item(arrowStack, itemX, itemY);
		graphics.itemDecorations(font, arrowStack, itemX, itemY);

		return SIDE_SLOT_ADVANCE;
	}

	private static ItemStack findArrowStack(LocalPlayer player) {
		ItemStack displayStack = ItemStack.EMPTY;
		int totalArrows = 0;
		boolean hasArrowsOutsideHotbar = false;

		for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
			ItemStack stack = player.getInventory().getItem(i);

			if (stack.isEmpty() || !stack.is(ItemTags.ARROWS)) {
				continue;
			}

			totalArrows += stack.getCount();

			if (i >= 9) {
				hasArrowsOutsideHotbar = true;
			}

			if (displayStack.isEmpty()) {
				displayStack = stack.copy();
			}
		}

		if (!hasArrowsOutsideHotbar || displayStack.isEmpty()) {
			return ItemStack.EMPTY;
		}

		displayStack.setCount(totalArrows);
		return displayStack;
	}

	private static boolean isHoldingBowOrCrossbow(LocalPlayer player) {
		return isBowOrCrossbow(player.getMainHandItem()) || isBowOrCrossbow(player.getOffhandItem());
	}

	private static boolean isBowOrCrossbow(ItemStack stack) {
		return stack.is(Items.BOW) || stack.is(Items.CROSSBOW);
	}

	private static void renderEffects(GuiGraphicsExtractor graphics, Minecraft minecraft, LocalPlayer player, int hotbarRight, int hotbarY, boolean offhandOnRight, int guiWidth, int guiHeight, int arrowOffset) {
		List<MobEffectInstance> effects = player.getActiveEffects().stream()
				.sorted(Comparator.comparingInt(CleanHUDRenderer::effectDurationForSorting))
				.toList();

		if (CleanHUDConfig.INSTANCE.effectHudPosition == EffectHudPosition.TOP) {
			renderEffectsTop(graphics, minecraft, effects, guiWidth, guiHeight);
		} else {
			renderEffectsBottom(graphics, minecraft.font, effects, hotbarRight, hotbarY, offhandOnRight, guiWidth, arrowOffset);
		}
	}

	private static void renderEffectsBottom(GuiGraphicsExtractor graphics, Font font, List<MobEffectInstance> effects, int hotbarRight, int hotbarY, boolean offhandOnRight, int guiWidth, int arrowOffset) {
		int startSlotX = hotbarRight + (offhandOnRight ? SIDE_SLOT_ADVANCE : 0) + arrowOffset;
		int slotX = startSlotX;
		int row = 0;

		EffectRenderState renderState = new EffectRenderState();

		for (MobEffectInstance effect : effects) {
			if (slotX + OFFHAND_BACKGROUND_WIDTH > guiWidth && slotX != startSlotX) {
				slotX = startSlotX;
				row++;
			}

			drawEffectSlot(graphics, font, effect, slotX, hotbarY - row * EFFECT_ROW_ADVANCE, false, renderState);
			slotX += GROUP_SLOT_ADVANCE;
		}

		finishEffectRendering(graphics, font, renderState);
	}

	private static void renderEffectsTop(GuiGraphicsExtractor graphics, Minecraft minecraft, List<MobEffectInstance> effects, int guiWidth, int guiHeight) {
		if (effects.isEmpty()) {
			return;
		}

		int maxSlotsPerRow = Math.max(1, (guiWidth - SCREEN_EDGE_PADDING * 2 - OFFHAND_BACKGROUND_WIDTH) / GROUP_SLOT_ADVANCE + 1);
		int topSlotY = topEffectY(minecraft, guiHeight);
		int renderedSlots = 0;

		EffectRenderState renderState = new EffectRenderState();

		for (int row = 0; renderedSlots < effects.size(); row++) {
			int rowSlots = Math.min(maxSlotsPerRow, effects.size() - renderedSlots);
			int startSlotX = centeredRowStart(guiWidth, rowSlots);
			int slotY = topSlotY + row * TOP_EFFECT_ROW_ADVANCE;

			for (int i = 0; i < rowSlots; i++) {
				drawEffectSlot(graphics, minecraft.font, effects.get(renderedSlots), startSlotX + i * GROUP_SLOT_ADVANCE, slotY, true, renderState);
				renderedSlots++;
			}
		}

		finishEffectRendering(graphics, minecraft.font, renderState);
	}

	private static void drawEffectSlot(GuiGraphicsExtractor graphics, Font font, MobEffectInstance effect, int slotX, int slotY, boolean topLayout, EffectRenderState renderState) {
		int itemX = slotX + EFFECT_ICON_X_OFFSET;
		int itemY = slotY + EFFECT_ICON_Y_OFFSET;
		String effectKey = effectBarKey(effect);

		renderState.activeEffectKeys.add(effectKey);

		if (CleanHUDConfig.INSTANCE.effectHudBackground) {
			drawOffhandBackground(graphics, slotX, slotY, false);
		}

		graphics.blitSprite(RenderPipelines.GUI_TEXTURED, effectIcon(effect), itemX, itemY, EFFECT_ICON_SIZE, EFFECT_ICON_SIZE);
		drawEffectDurationBar(graphics, effect, effectKey, itemX, itemY);
		addEffectAmplifierText(font, effect, itemX, itemY, renderState.amplifierTexts);
		addEffectWarningText(font, effect, itemX, itemY, topLayout, renderState.warningTexts);
	}

	private static void finishEffectRendering(GuiGraphicsExtractor graphics, Font font, EffectRenderState renderState) {
		for (EffectText amplifierText : renderState.amplifierTexts) {
			drawTextWithShadow(graphics, font, amplifierText.text, amplifierText.x, amplifierText.y, amplifierText.color);
		}

		for (EffectText warningText : renderState.warningTexts) {
			drawTextWithShadow(graphics, font, warningText.text, warningText.x, warningText.y, warningText.color);
		}

		EFFECT_MAX_DURATIONS.keySet().removeIf(key -> !renderState.activeEffectKeys.contains(key));
	}

	private static void addEffectAmplifierText(Font font, MobEffectInstance effect, int itemX, int itemY, List<EffectText> amplifierTexts) {
		if (effect.getAmplifier() <= 0) {
			return;
		}

		String text = Integer.toString(effect.getAmplifier() + 1);
		int x = itemX + EFFECT_ICON_SIZE - font.width(text) + 1;
		int y = itemY + EFFECT_ICON_SIZE - font.lineHeight + 2;

		amplifierTexts.add(new EffectText(text, x, y, TEXT_COLOR));
	}

	private static void addEffectWarningText(Font font, MobEffectInstance effect, int itemX, int itemY, boolean topLayout, List<EffectText> warningTexts) {
		if (effect.isInfiniteDuration()) {
			return;
		}

		int seconds = effectSeconds(effect);

		if (seconds > 10) {
			return;
		}

		String text = seconds + "s";
		int x = itemX + EFFECT_ICON_SIZE / 2 - font.width(text) / 2;
		int y = topLayout ? itemY + EFFECT_ICON_SIZE + 1 : Math.max(SCREEN_EDGE_PADDING, itemY - 12);
		int color = seconds <= 3 ? LOW_TEXT_COLOR : TEXT_COLOR;

		warningTexts.add(new EffectText(text, x, y, color));
	}

	private static void drawEffectDurationBar(GuiGraphicsExtractor graphics, MobEffectInstance effect, String effectKey, int itemX, int itemY) {
		if (effect.isInfiniteDuration()) {
			return;
		}

		int duration = Math.max(0, effect.getDuration());
		int maxDuration = Math.max(duration, EFFECT_MAX_DURATIONS.getOrDefault(effectKey, duration));

		EFFECT_MAX_DURATIONS.put(effectKey, maxDuration);

		if (maxDuration <= 0) {
			return;
		}

		int barX = itemX + 2;
		int barY = itemY + EFFECT_ICON_SIZE - 3;
		int barMaxWidth = EFFECT_ICON_SIZE - 3;
		int barWidth = Math.max(0, Math.min(barMaxWidth, Math.round((float) barMaxWidth * duration / maxDuration)));
		int red = Math.min(255, 255 - Math.round(255.0F * barWidth / barMaxWidth));
		int green = Math.min(255, Math.round(255.0F * barWidth / barMaxWidth));
		int color = 0xFF000000 | red << 16 | green << 8;

		graphics.fill(barX, barY, barX + barMaxWidth, barY + 2, 0xFF000000);
		graphics.fill(barX, barY, barX + barWidth, barY + 1, color);
	}

	private static Identifier effectIcon(MobEffectInstance effect) {
		return effect.getEffect().unwrapKey()
				.map(key -> key.identifier().withPrefix("mob_effect/"))
				.orElse(Identifier.withDefaultNamespace("missingno"));
	}

	private static int effectDurationForSorting(MobEffectInstance effect) {
		return effect.isInfiniteDuration() ? Integer.MAX_VALUE : effect.getDuration();
	}

	private static String effectBarKey(MobEffectInstance effect) {
		return effectIcon(effect) + ":" + effect.getAmplifier();
	}

	private static int effectSeconds(MobEffectInstance effect) {
		return Math.max(0, (effect.getDuration() + 19) / 20);
	}

	private static int centeredRowStart(int guiWidth, int rowSlots) {
		int rowWidth = OFFHAND_BACKGROUND_WIDTH + (rowSlots - 1) * GROUP_SLOT_ADVANCE;
		return guiWidth / 2 - rowWidth / 2;
	}

	private static int topEffectY(Minecraft minecraft, int guiHeight) {
		int bossBars = bossBarCount(minecraft);
		int y = 4;

		if (bossBars <= 0) {
			return y;
		}

		y = 12;

		for (int i = 0; i < bossBars; i++) {
			y += 19;

			if (y >= guiHeight / 3) {
				break;
			}
		}

		return y + 3;
	}

	private static int bossBarCount(Minecraft minecraft) {
		Object bossOverlay = findBossOverlay(minecraft, 0);

		if (bossOverlay == null) {
			return 0;
		}

		for (Field field : bossOverlay.getClass().getDeclaredFields()) {
			if (!Map.class.isAssignableFrom(field.getType())) {
				continue;
			}

			try {
				field.setAccessible(true);
				Object value = field.get(bossOverlay);

				if (value instanceof Map<?, ?> map) {
					return map.size();
				}
			} catch (ReflectiveOperationException | RuntimeException ignored) {
			}
		}

		return 0;
	}

	private static Object findBossOverlay(Object object, int depth) {
		if (object == null || depth > 2) {
			return null;
		}

		if (object.getClass().getSimpleName().toLowerCase().contains("boss")) {
			return object;
		}

		for (Field field : object.getClass().getDeclaredFields()) {
			try {
				field.setAccessible(true);
				Object value = field.get(object);

				if (value == null || value == object) {
					continue;
				}

				Object bossOverlay = findBossOverlay(value, depth + 1);

				if (bossOverlay != null) {
					return bossOverlay;
				}
			} catch (ReflectiveOperationException | RuntimeException ignored) {
			}
		}

		return null;
	}

	private static void renderClock(GuiGraphicsExtractor graphics, Font font, int guiWidth, int guiHeight) {
		String time = LocalTime.now().format(CLOCK_FORMAT);
		int x = guiWidth - font.width(time) - CLOCK_PADDING - CLOCK_RIGHT_EXTRA_PADDING;
		int y = guiHeight - font.lineHeight - CLOCK_PADDING;

		drawTextWithShadow(graphics, font, time, x, y, TEXT_COLOR);
	}

	private static void drawTextWithShadow(GuiGraphicsExtractor graphics, Font font, String text, int x, int y, int color) {
		graphics.text(font, text, x + 1, y + 1, SHADOW_COLOR, false);
		graphics.text(font, text, x, y, color, false);
	}

	private static void drawOffhandBackground(GuiGraphicsExtractor graphics, int x, int y, boolean leftSide) {
		graphics.blitSprite(RenderPipelines.GUI_TEXTURED, leftSide ? HOTBAR_OFFHAND_LEFT_SPRITE : HOTBAR_OFFHAND_RIGHT_SPRITE, x, y, OFFHAND_BACKGROUND_WIDTH, OFFHAND_BACKGROUND_HEIGHT);
	}

	private static class EffectRenderState {
		private final Set<String> activeEffectKeys = new HashSet<>();
		private final List<EffectText> amplifierTexts = new ArrayList<>();
		private final List<EffectText> warningTexts = new ArrayList<>();
	}

	private static class EffectText {
		private final String text;
		private final int x;
		private final int y;
		private final int color;

		private EffectText(String text, int x, int y, int color) {
			this.text = text;
			this.x = x;
			this.y = y;
			this.color = color;
		}
	}
}
